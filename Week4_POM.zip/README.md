# Week4 POM Automation Project

Run tests with:
pytest -q
